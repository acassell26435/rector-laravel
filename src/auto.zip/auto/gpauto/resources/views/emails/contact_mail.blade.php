<h3>New Contact Via Contact Form</h3>
<div>
  Name: {{$data['name']}}
</div>
<br>
<div>
  Subject: {{$data['subject']}}
</div>
<br>
<div>
  Message: {{$data['mail_message']}}
</div>
<br>
<p>Sent Via {{$data['email']}}</p>
